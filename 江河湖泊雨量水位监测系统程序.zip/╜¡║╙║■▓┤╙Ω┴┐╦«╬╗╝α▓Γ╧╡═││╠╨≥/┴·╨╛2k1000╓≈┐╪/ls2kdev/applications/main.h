#ifndef _MAIN_H
#define _MAIN_H
#include <rtthread.h>
#include <rtdevice.h>
#include "../drivers/ls2k_delay.h"
#include "dht12.h"
#include "oledi2c.h"
extern struct rt_i2c_bus_device *i2c_bus;      /* I2C总线设备句柄 */
extern float level,rainfall;
#endif
