/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-04-05     bigmagic    first version
 */

#include "main.h"

struct rt_i2c_bus_device *i2c_bus;      /* I2C总线设备句柄 */
float level,rainfall;

int main(int argc, char** argv)
{
	int status;
	rt_device_t uart;
	char rec_buff[200],send_buff;
	uart = rt_device_find("uart4");
    if(uart==RT_NULL)
    {
        rt_kprintf("the device not found\n");  
        //while(1);
    }
	rt_device_init(uart);//对串口4进行初始化
	status=rt_device_open(uart,RT_SERIAL_EVENT_RX_IND);
	i2c_bus = (struct rt_i2c_bus_device *)rt_device_find("i2c0");

    if(status!=RT_EOK)
    {
        rt_kprintf("open error\n");

		
    }
	OLED_Init();
	while(1)
	{
		DHT12_get_val();
		show_picture1();
		delay_us(100000);
		show_picture2();
		delay_us(100000);
	}
	show_picture1();
	delay_us(10000);
	show_picture2();
	
}