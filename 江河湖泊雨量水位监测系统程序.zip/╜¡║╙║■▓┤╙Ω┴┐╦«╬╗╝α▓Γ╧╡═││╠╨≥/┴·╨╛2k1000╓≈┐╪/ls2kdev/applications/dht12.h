#ifndef _DHT12_H
#define _DHT12_H
#include "main.h"

int DHT12_get_val(void);
extern float temperature,humidity;

#endif