/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-04-05     bigmagic    first version
 */

#include <rtthread.h>
#include <rtdevice.h>
#include "../drivers/ls2k_delay.h"
#define AHT10_ADDR 0x40
unsigned char  TRIG_TEMP_MEASUREMENT_POLL = 0xF3; //温度 测量，保持主机		命令
unsigned char  TRIG_HUMI_MEASUREMENT_POLL = 0xF5; //湿度 测量，保持主机		命令
static rt_err_t read_regs(struct rt_i2c_bus_device *bus, rt_uint8_t len, rt_uint8_t *buf)
{
       struct rt_i2c_msg msgs;

       msgs.addr = AHT10_ADDR;     /* 从机地址 */
       msgs.flags = RT_I2C_RD;     /* 读标志 */
       msgs.buf = buf;             /* 读写数据缓冲区指针　*/
       msgs.len = len;             /* 读写数据字节数 */

        /* 调用I2C设备接口传输数据 */
        if (rt_i2c_transfer(bus, &msgs, 1) == 1)
        {
            return RT_EOK;
        }
        else
        {
            return -RT_ERROR;
        }
    }
static rt_err_t write_reg(struct rt_i2c_bus_device *bus, rt_uint8_t reg, rt_uint8_t *data)
{
    rt_uint8_t buf[3];
    struct rt_i2c_msg msgs;

    buf[0] = reg; //cmd

    msgs.addr = AHT10_ADDR;
    msgs.flags = RT_I2C_WR;
    msgs.buf = buf;
    msgs.len = 1;

    /* 调用I2C设备接口传输数据 */
    if (rt_i2c_transfer(bus, &msgs, 1) == 1)
    {
        return RT_EOK;
    }
    else
    {
        return -RT_ERROR;
    }
}
int main(int argc, char** argv)
{
    struct rt_i2c_bus_device *i2c_bus;      /* I2C总线设备句柄 */
    rt_uint8_t data[20];
    rt_uint8_t buffer[20];
    rt_uint16_t temp_16,i,lcyy;
    float temperature;
    i2c_bus = (struct rt_i2c_bus_device *)rt_device_find("i2c0");

    write_reg(i2c_bus,TRIG_TEMP_MEASUREMENT_POLL,data);
    //rt_thread_delay(1);
    delay_us(100000);
    read_regs(i2c_bus,2,buffer);
	for (i = 0; i < 2; i++)	buffer[i] &=0xff;
	temp_16 = (buffer[0] << 8) | (buffer[1] << 0);
	temp_16 &= ~0x0003;
	lcyy = ((float)temp_16 * 0.00268127) - 46.85;
    //lcyy=temperature;

    rt_kprintf("the temp is %d℃\n",lcyy);   

    rt_kprintf("Hi, this is RT-Thread4444!!\n");
    return 0;
}