/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-04-05     bigmagic    first version
 */

#include "main.h"

struct rt_i2c_bus_device *i2c_bus;      /* I2C总线设备句柄 */
float level,rainfall = 0;
float rain=0;

int main(int argc, char** argv)
{
	int status,count;
    char trans_buffer[10] = {0};
	rt_device_t uart;
	char rec_buff[200],send_buff;
	uart = rt_device_find("uart4");
    if(uart==RT_NULL)
    {
        rt_kprintf("the device not found\n");  
        //while(1);
    }
	rt_device_init(uart);//对串口4进行初始化
	status=rt_device_open(uart,RT_SERIAL_EVENT_RX_IND);
	i2c_bus = (struct rt_i2c_bus_device *)rt_device_find("i2c0");

    if(status!=RT_EOK)
    {
        rt_kprintf("open error\n");
    }
	OLED_Init();
	
	float read_rain(void)
	{

		rec_buff[0]=0;
		rec_buff[2]=0;
		rt_device_read(uart, -1, &rec_buff, 3);
		if((rec_buff[0] == 0xBB)&(rec_buff[2] == 0xCC))	
		{
			count++;
			rt_kprintf("the count is %d\n",count);
		    rt_kprintf("the rain is %d\n",rec_buff[1]);
	        rain = (rec_buff[1]-0x30)*0.2;
		}
		rt_kprintf("the rain is %d\n",rec_buff[1]);
		return rain;
	}
	void datapack(void)
	{
        trans_buffer[0] = 0xBB;

		trans_buffer[1] = (char)rainfall;
		trans_buffer[2] = ((char)(rainfall*10))%10;		
		trans_buffer[3] = (char)level;
		trans_buffer[4] = ((char)(level*10))%10;
		trans_buffer[5] = (char)temperature;
		trans_buffer[6] = ((char)(temperature*100))%100;
		trans_buffer[7] = (char)humidity;
		trans_buffer[8] = ((char)(humidity*100))%100;
		trans_buffer[9] = 0xCC;
	}

	while(1)
	{

		DHT12_get_val();
	    rainfall = read_rain();
     //   rt_kprintf("%f\n",rainfall);
        datapack();
		rt_device_write(uart,-1,trans_buffer,10);
		show_picture1();
		delay_us(100000);
		show_picture2();
		delay_us(100000);
		//memset(trans_buffer,0,sizeof(trans_buffer));
	}
	show_picture1();
	delay_us(10000);
	show_picture2();
	//memset(rec_buff,0,200);
	
}