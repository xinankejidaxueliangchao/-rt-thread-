
unsigned long clk_get_apb_rate(void)
{
    return 125000000;
}