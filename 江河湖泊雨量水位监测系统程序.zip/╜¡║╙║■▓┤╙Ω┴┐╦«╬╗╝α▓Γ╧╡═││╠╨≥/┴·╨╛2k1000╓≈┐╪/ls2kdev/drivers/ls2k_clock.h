#ifndef __OPENLOONGSON_CLOCK_H
#define __OPENLOONGSON_CLOCK_H


/*
 * 获取CPU频率
 * @ret CPU频率
 */
unsigned long clk_get_cpu_rate(void);

#endif