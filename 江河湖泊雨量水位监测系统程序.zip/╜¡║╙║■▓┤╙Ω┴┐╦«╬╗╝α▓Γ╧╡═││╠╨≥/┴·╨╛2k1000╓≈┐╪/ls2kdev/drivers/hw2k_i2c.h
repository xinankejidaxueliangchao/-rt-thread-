/*
 * Copyright (c) 2006-2018, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2018-01-04     Sundm75        the first version
 */

#ifndef LS2K_I2C_H
#define LS2K_I2C_H

#include <rtthread.h>
#define I2C_base 0xbfe00000

int rt_i2c_init(void);

#endif 
