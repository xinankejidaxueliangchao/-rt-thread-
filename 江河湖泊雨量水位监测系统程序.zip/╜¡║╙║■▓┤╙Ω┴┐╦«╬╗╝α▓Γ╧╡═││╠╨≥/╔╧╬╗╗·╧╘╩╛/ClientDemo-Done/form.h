﻿#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include "myclient.h"
#include <ActiveQt/QAxObject>

class myclient;
namespace Ui {
class Form;
}

class Form : public QWidget
{
    Q_OBJECT

public:
    explicit Form(QWidget *parent = 0);
    ~Form();
    void SaveExcel(const QString &fileName);
    void setinformation(int row, int line, QString Information);

private:
    Ui::Form *ui;
    myclient *client;
    int buf_len=0;
    QAxObject *pApplication;
    QAxObject *pWorkBooks;
    QAxObject *pWorkBook;
    QAxObject *pSheets;
    QAxObject *pSheet;
    struct Mystr{
        QString temp1;
        QString temp2;
        QString temp3;
        QString temp4;
        QString humi1;
        QString humi2;
        QString humi3;
        QString humi4;

    }buffer_data[20];
private slots:


    void dataDis(QString);
    void on_pushButton_clicked();

    void on_label_11_linkActivated(const QString &link);
};

#endif // FORM_H
