﻿#include "myclient.h"

QString IP; //设置默认IP和port，对于本地是127.0.0.1，对于云服务器则使用对应公网IP
int port;   //port注意服务端与客户端一致
QString msg;
myclient::myclient(QObject *parent) : QObject(parent)
{
    status = false;
    IP = "129.211.87.210"; //IP地址，对于本地使用127.0.0.1，对于云服务器，使用对应公网IP即可
    port = 8008; //端口号需要与服务端监听的对应
    this->slotEnter();
    this->slotSend();
}


void myclient::slotEnter()
{

    if(!status)
    {
        tcpSocket = new QTcpSocket(this);
        //检测链接信号
        connect(tcpSocket,SIGNAL(connected()),this,SLOT(slotConnected()));
        //检测如果断开
        connect(tcpSocket,SIGNAL(disconnected()),this,SLOT(slotDisconnected()));
        //检测如果有新可以读信号
        connect(tcpSocket,SIGNAL(readyRead()),this,SLOT(dataReceived()));

        tcpSocket->connectToHost(IP,port);
        //连接服务端
        status=true;
    }
    else
    {
        tcpSocket->disconnectFromHost();

        status=false;
    }
}
//链接后
void myclient::slotConnected()
{

    //int length=0;
}

void myclient::slotSend()
{

    QString msg="22"; //22即查询所有数据
    tcpSocket->write(msg.toLatin1(),msg.length());
}

void myclient::slotDisconnected()
{
}

void myclient::dataReceived()
{
    QString bufRcv;
    while(tcpSocket->bytesAvailable()>0)
    {
        QByteArray datagram;
        datagram.resize(tcpSocket->bytesAvailable());

        tcpSocket->read(datagram.data(),datagram.size()); //读取到的数据存放到datagram中，对于
                                      //字节型数据可以通过  datagram.at(i)查看

        msg=datagram.toHex();
        bufRcv.prepend(msg);
        qDebug()<<"bufRcv :"<<bufRcv; //msg为云服务器所发出数据,设置为全局变量可以在其他函数进行调用
        emit dataRcv(msg.toLatin1());
        msg.clear();

    }
}
