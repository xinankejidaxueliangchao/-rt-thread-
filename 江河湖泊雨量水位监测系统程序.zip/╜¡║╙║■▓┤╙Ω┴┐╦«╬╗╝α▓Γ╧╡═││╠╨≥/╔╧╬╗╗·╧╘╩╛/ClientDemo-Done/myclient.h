#ifndef MYCLIENT_H
#define MYCLIENT_H

#include <QObject>
#include <QTcpSocket>
#include "form.h"
class myclient : public QObject
{
    Q_OBJECT
public:
    explicit myclient(QObject *parent = nullptr);

private:
    bool status;
    int port;
    QHostAddress *serverIP;
    QString userName;
    QTcpSocket *tcpSocket;
public slots:
    void slotEnter();
    void slotConnected();
    void slotDisconnected();
    void dataReceived();
    void slotSend();
signals:
    void dataRcv(QString);
};

#endif // MYCLIENT_H
