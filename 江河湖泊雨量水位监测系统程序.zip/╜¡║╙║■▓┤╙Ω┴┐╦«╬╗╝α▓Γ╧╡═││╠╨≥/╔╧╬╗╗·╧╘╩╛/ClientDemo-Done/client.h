#ifndef CLIENT_H
#define CLIENT_H

#include <QTcpSocket>


QHostAddress *serverIP;
QString userName;
QTcpSocket *tcpSocket;

void slotEnter();
void slotConnected();
void slotDisconnected();
void dataReceived();
void slotSend();

#endif // CLIENT_H
