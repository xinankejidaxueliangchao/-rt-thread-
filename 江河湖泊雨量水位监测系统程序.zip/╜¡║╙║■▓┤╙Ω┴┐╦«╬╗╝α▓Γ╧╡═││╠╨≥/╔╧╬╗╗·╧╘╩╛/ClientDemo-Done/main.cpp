#include <QApplication>
#include "myclient.h"


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Form win;
    win.show();

    //myclient m;
    return a.exec();
}

