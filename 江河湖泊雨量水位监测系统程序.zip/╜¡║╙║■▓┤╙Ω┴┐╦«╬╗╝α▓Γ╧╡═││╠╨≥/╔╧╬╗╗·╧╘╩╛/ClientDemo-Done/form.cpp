﻿#include "form.h"
#include "ui_form.h"
#include <QDebug>
#include <QFile>
#include <QFileDialog>
#include <QTextStream>
#include <QApplication>
#include <QDir>
#include <QByteArray>
#include <QDesktopServices>

extern QString msg;
//QString Msg = "bb1ccc2d";

QString rain_Stand  = "250.0";
QString water_Stand  = "50.0";


Form::Form(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Form)
{

    ui->setupUi(this);
    pApplication=NULL;
    pWorkBooks=NULL;
    pWorkBook=NULL;
    pSheets=NULL;
    pSheet=NULL;
    buf_len=0;
    client = new myclient;
    connect(client,SIGNAL(dataRcv(QString)),this,SLOT(dataDis(QString)));
}

Form::~Form()
{
    delete ui;
}

void Form::dataDis(QString Msg)
{
    bool ok;
    qDebug()<<"buf is:"<<Msg;

    QString  rainData_11 = Msg.mid(2 , 2);
     QString  rainData_12 = Msg.mid(4 , 2);
   //QString  rainData_1 = Msg.mid(2 , 4);

    QString  Waterdata_11= Msg.mid(6 , 2);
    QString  Waterdata_12= Msg.mid(8 , 2);

      QString  wendu1= Msg.mid(10 , 2);
      QString  wendu2= Msg.mid(12 , 2);

      QString  shidu1= Msg.mid(14 , 2);
      QString  shidu2= Msg.mid(16 , 2);


    //雨量数据处理
    rainData_11 = QByteArray::number(rainData_11.toLongLong(&ok,16),10);  //hex to Qstring int
    rainData_12 = QByteArray::number(rainData_12.toLongLong(&ok,16),10);  //hex to Qstring int
   // rainData_1 = QByteArray::number(rainData_1.toLongLong(&ok,16),10);  //hex to Qstring int
   // rainData_1.insert(2, QString("."));  //显示为真实数字
    QString  rain = rainData_11+"."+rainData_12+"mm";

  //  float tmp = rainData_1.toFloat();

   // tmp=0.2*(tmp-48);
   // QString rain = QString("%1").arg(tmp);
    //   rainData_1.insert(2, QString("."));  //显示为真实数字
    //rain.insert(5, QString("mm")); //加入单位

    //水位数据处理
    Waterdata_11 = QByteArray::number(Waterdata_11.toLongLong(&ok,16),10);  //hex to Qstring int
    Waterdata_12 = QByteArray::number(Waterdata_12.toLongLong(&ok,16),10);  //hex to Qstring int
    QString  Waterdata_1 = Waterdata_11+"."+Waterdata_12+"cm";
   // Waterdata_1.insert(2, QString("."));  //显示为真实数字
   // Waterdata_1.insert(5, QString("cm")); //加入单位

    //温度数据处理
    wendu1 = QByteArray::number(wendu1.toLongLong(&ok,16),10);  //hex to Qstring int
    wendu2 = QByteArray::number(wendu2.toLongLong(&ok,16),10);  //hex to Qstring int
    QString  wendu = wendu1+"."+wendu2+"℃";
   // wendu.insert(2, QString("."));  //显示为真实数字
   // wendu.insert(5, QString("℃")); //加入单位

    //湿度数据处理
    shidu1 = QByteArray::number(shidu1.toLongLong(&ok,16),10);  //hex to Qstring int
    shidu2 = QByteArray::number(shidu2.toLongLong(&ok,16),10);  //hex to Qstring int
     QString  shidu = shidu1+"."+shidu2+"%rh";
    //shidu.insert(2, QString("."));  //显示为真实数字
    //shidu.insert(5, QString("%rh")); //加入单位

    qDebug()<<rain;

    qDebug()<<Waterdata_1;

    qDebug()<<wendu;
    qDebug()<<shidu;


    buffer_data[buf_len].temp1=rain;
    buffer_data[buf_len].humi1=Waterdata_1;
    buffer_data[buf_len].temp2=wendu;
    buffer_data[buf_len].humi2=shidu;

    QFont font = QFont("Times New Roman",28,4);
   // if(rain >= rain_Stand) {
  //    ui->Temp_1->setTextColor(Qt::red);
   // }
   // else {
      ui->Temp_1->setTextColor(Qt::black);
   // }

    ui->Temp_1->setText(rain);
    ui->Temp_1->setFont(font);

    ui->Temp_2->setText(wendu);
    ui->Temp_2->setFont(font);

   // if(Waterdata_1 <= water_Stand) {
    //  ui->Humi_1->setTextColor(Qt::red);
   // }
   // else {
      ui->Humi_1->setTextColor(Qt::black);
  //  }

    ui->Humi_1->setText(Waterdata_1);
    ui->Humi_1->setFont(font);

    ui->Humi_2->setText(shidu);
    ui->Humi_2->setFont(font);


    buf_len=buf_len+1;
    msg.clear();

}

void Form::on_pushButton_clicked()
{
    QString fileName=QFileDialog::getSaveFileName(NULL,"save file",".","Excel File(*.xls)");
    SaveExcel(fileName);
}

//生成表格信息
void Form::SaveExcel(const QString &fileName)
{
    int tim;
    //初始化
    pApplication = new QAxObject();
    pApplication->setControl("Excel.Application");
    pApplication->dynamicCall("SetVisible(bool)",false);
    pApplication->setProperty("DisplayAlerts", false);
    pWorkBooks=pApplication->querySubObject("WorkBooks");
    pWorkBooks->dynamicCall("ADD");
    pWorkBook=pApplication->querySubObject("ActiveWorkBook");
    pSheets=pWorkBook->querySubObject("Sheets");
    pSheet=pSheets->querySubObject("Item(int)",1);
    //       写数据
    setinformation(1,1,"雨量");
    setinformation(1,2,"水位");
    setinformation(1,3,"温度");
    setinformation(1,4,"湿度");

    for(tim=0;tim<buf_len;tim++)
    {
        //节点1
        setinformation(tim+2,1,buffer_data[tim].temp1);
        setinformation(tim+2,2,buffer_data[tim].humi1);
        setinformation(tim+2,3,buffer_data[tim].temp2);
        setinformation(tim+2,4,buffer_data[tim].humi2);
    }

    buf_len = 0;
 //      转换格式保存
    pWorkBook->dynamicCall("SaveAs(const QString&)",QDir::toNativeSeparators(fileName));
    pWorkBook->dynamicCall("Close(Boolean)",false);
    pApplication->dynamicCall("Quit(void)");
}
//  在row行，line列加入信息
void Form::setinformation(int row,int line, QString Information)
{
     pSheet->querySubObject("Cells(int,int)",row,line)->setProperty("Value",Information);
}

